import { editorConfig, ClassicEditor } from 'js/mainCkeditor.js'

ClassicEditor.create(document.querySelector('#editor-des'), editorConfig);
