<?php
define('_HOST', 'http://localhost:8050/');
//connect DB
define('_DNS', 'mysql:host=localhost;dbname=asm_pro1;charset=utf8mb4');
define('_USER_NAME', 'root');
define('_PASSWORD', '');
// config mailer
define('_PASSWORD_MAILER', 'lgpdlwjvdxgixscj');
//jwt
define('_SECRET_KEY', 'forestline19307');
