<?php
class Review extends Controller
{
    public function render($data)
    {
        $this->view('layout/layout_admin', $data);
    }
    public function index()
    {
        $data['page'] = 'detail/list_review';        
        $this->render($data);
    }
    
    public function upload_image($name, $tmp_name)
    {
        $path = "./uploads/" . $name;
        $imageName = strtolower(pathinfo($path,  PATHINFO_FILENAME)) . 'Copy';
        $imageFileType = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $count = 1;
        $imageNew = "./uploads/" . $imageName . '.' . $imageFileType;
        while (file_exists($imageNew)) {
            $imageNew = "./uploads/" . $imageName . $count . '.' . $imageFileType;
            $count++;
        }
        move_uploaded_file($tmp_name, $imageNew);
        return substr($imageNew, 10);
    }
    public function add_review()
    {
        $review = $this->model('M_review');
        if (isset($_GET['action']) && $_GET['action'] == 'add_review') {
            $image = $this->model('M_image');
            $imageNew = $this->upload_image($_FILES['image_review']['name'], $_FILES['image_review']['tmp_name']);
            $new_review_id = $review->add_review(
             $_POST['title'], image_review: $imageNew, content: $_POST['content'],
             author: $_POST['author']);
            $i = 0;
            foreach ($_FILES['image_detail']['name'] as $value) {
                $imageNew = $this->upload_image($value, $_FILES['image_detail']['tmp_name'][$i]);
                $image->add_image_review($new_review_id, $imageNew);
                $i++;
            }
            header("Location: " . _HOST . "/admin/review/list_review/");
        }
        $data['title'] = "Thêm đánh giá";
        $data['page'] = 'review/add_review';
        $this->render($data);
    }
    public function list_review()
    {
        $data['title'] = "Danh sách đánh giá";
        $review = $this->model('M_review');
        $data['review'] = $review->get_review_all_admin();
        $data['page'] = 'review/list_review';
        $this->render($data);
    }
    public function update_review($id = null)
    {    
        $review_variant = $this->model('M_review');
        $review = $this->model('M_review');
        $data['review'] = $review->get_review_all();
        $data['review'] = $review_variant->get_review_one($id);
        $data['list_review_variant'] = $review_variant->get_review_variant_by_id($id);
        $data['title'] = "Update đánh giá";
        $data['page'] = 'review/update_review';
        if (isset($_GET['action'])) {
            switch ($_GET['action']) {            
                case 'update_review':
                    if (!$_FILES['image_review']['name']) {
                        $path_image = $_POST['image_review'];
                    } else {
                        $path_image = $_FILES['image_post']['name'];
                        $proImage = "./uploads/" . basename($_FILES['image_post']['name']);
                        move_uploaded_file($_FILES['image_post']['tmp_name'], $proImage);
                    }                                
                    $this->model('M_review')->edit_review(
                        $id,
                        $_POST['title'],
                        image_review: $path_image,
                        content: $_POST['content'],                       
                        author: $_POST['author'],
/*                         date: $_POST['date']
 */                    );                   
                    header("Location: " . _HOST . "/admin/review/list_review");
                    break;              
                    case 'set-status-review':
                        $status = ($_GET['status'] == 1) ? 0 : 1;
                        $review = $this->model('M_review');

                        $review->set_status_review($id, $status);
                        header("Location: " . _HOST . "/admin/review/list_review/");
                        break;
                default:

                    echo "Hành động không hợp lệ!";
                    break;
            }
        }
        $this->render($data);
    }

    public function edit_review($id, $title, $content, $image_review, $author, $date)
    {
        $review = $this->model('M_review');
        return $review->edit_review($id, $title, $content, $image_review, $author, $date);
    }
}
