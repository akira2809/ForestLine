<div id="reviewPopup" class="modal" tabindex="-1" role="dialog" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Đánh giá sản phẩm</h5>
                <button type="button" class="close" onclick="closeReviewPopup()" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="reviewForm" method="post" action="/mvc/controllers/admin/Review.php">
                    <div class="form-group">
                        <label for="reviewText">Đánh giá của bạn:</label>
                        <textarea id="reviewText" name="content" class="form-control" rows="3" placeholder="Nhập đánh giá của bạn"></textarea>
                    </div>

                    <div class="form-group">
                        <label for="reviewImage">Chọn ảnh:</label>
                        <input type="file" name="images" id="reviewImage" class="form-control" accept="image/*">
                    </div>
                    
                    <div class="stars mt-2">
                        <input
                        class="star star-5"
                        id="star-5"
                        type="radio"
                        name="star"
                        />
                        <label class="star star-5" for="star-5"></label>
                        <input
                        class="star star-4"
                        id="star-4"
                        type="radio"
                        name="star"
                        />
                        <label class="star star-4" for="star-4"></label>
                        <input
                        class="star star-3"
                        id="star-3"
                        type="radio"
                        name="star"
                        />
                         <label class="star star-3" for="star-3"></label>
                        <input
                        class="star star-2"
                        id="star-2"
                        type="radio"
                        name="star"
                        />
                        <label class="star star-2" for="star-2"></label>
                        <input
                        class="star star-1"
                        id="star-1"
                        type="radio"
                        name="star"
                        />
                        <label class="star star-1" for="star-1"></label>
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                        <button type="submit" name="send-rating" class="btn btn-primary mt-3">Gửi đánh giá</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>