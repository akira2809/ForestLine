<?php
session_start();
// unset($_SESSION['user_login']);
require_once './mvc/Bridge.php';

$myApp = new App();
